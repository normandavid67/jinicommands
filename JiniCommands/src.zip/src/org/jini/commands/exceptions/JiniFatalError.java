/*
 * Licensed under GNU GENERAL PUBLIC LICENSE Version 1 you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.gnu.org/licenses/gpl-1.0.txt
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * For a copy of the License type 'license'
 */
package org.jini.commands.exceptions;

/**
 * 
 * @author Norman David <normandavid67@gmail.com>
 * @since JiniCommands version 0.1
 * @version 1.0
 */
public final class JiniFatalError extends Exception implements JiniErrors {

    private static final long serialVersionUID = 1L;
    public JiniFatalError() {

    }

    public JiniFatalError(String message) {

        super(message);

        this.writeErrorToConsole(message);
 
        this.exitJvm();

    }

    public JiniFatalError(String message, Throwable cause) {

        super(message, cause);

        this.writeErrorToConsole(message);
 
        this.exitJvm();
    }

    public JiniFatalError(Throwable cause) {
        super(cause);
    }

    @Override
    public void writeErrorToConsole(String err) {
        System.err.println("Fatal Error : " + err);
    }

    private void exitJvm() {
        System.exit(1);

    }

}


